package kr.green.adidas.vo;

import java.util.List;

import lombok.Data;

@Data
public class ListOrderListVO {
	private List<OrderListVO> list;
}
