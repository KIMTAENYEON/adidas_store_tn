package kr.green.adidas.vo;

import lombok.Data;

@Data
public class SelectVO {
	
	private String se_gender;
	private int se_ca_num;
	private int se_sub_num;
	private String se_new;
	private int se_min_price;
	private int se_max_price;
	private int se_lineup;
	
}
