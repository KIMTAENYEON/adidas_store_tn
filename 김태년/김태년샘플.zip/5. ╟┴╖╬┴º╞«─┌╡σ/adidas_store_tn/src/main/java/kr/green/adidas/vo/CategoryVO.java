package kr.green.adidas.vo;

import lombok.Data;

@Data
public class CategoryVO {
	private int ca_num;
	private String ca_name;
}
