package kr.green.adidas.vo;

import lombok.Data;

@Data
public class SubCategoryVO {
	private int sub_num;
	private String sub_name;
	private int sub_ca_num;
}
