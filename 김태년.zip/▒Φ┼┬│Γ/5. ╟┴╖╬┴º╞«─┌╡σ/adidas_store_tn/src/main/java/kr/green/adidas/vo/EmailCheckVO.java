package kr.green.adidas.vo;

import lombok.Data;

@Data
public class EmailCheckVO {
	
	private int em_num;
	private String em_email;
	private String em_checknum;
}
