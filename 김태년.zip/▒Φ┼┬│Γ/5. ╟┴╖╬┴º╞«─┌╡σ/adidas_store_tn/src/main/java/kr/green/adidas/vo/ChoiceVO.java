package kr.green.adidas.vo;

import lombok.Data;

@Data
public class ChoiceVO {
	private int ch_num;
	private int ch_state;
	private String ch_me_email;
	private int ch_gd_num;
}
