package kr.green.adidas.vo;

import lombok.Data;

@Data
public class MyListVO {
	private int my_num;
	private int my_amount;
	private String my_me_email;
	private int my_op_num;
}
