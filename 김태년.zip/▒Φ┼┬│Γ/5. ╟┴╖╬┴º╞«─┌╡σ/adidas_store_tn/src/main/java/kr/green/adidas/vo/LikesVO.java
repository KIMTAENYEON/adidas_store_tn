package kr.green.adidas.vo;

import lombok.Data;

@Data
public class LikesVO {

	private int li_num;
	private int li_state;
	private String li_me_email;
	private int li_re_num;
}
