package kr.green.adidas.vo;

import lombok.Data;

@Data
public class OptionVO {
	
	private int op_num;
	private int op_gd_num;
	private String op_size;
	private int op_amount;
}
